export const WORKS_DOC = {
  "ok": true,
  "author": "Aziel Eliab",
  "title": "Aziel Corpus Library",
  "library": "https://www.azielcorpuslibrary.net/",
  "library_fallback": "https://aziel-corpus-download-tracker.vibelock.workers.dev/",
  "license": "Apache-2.0",
  "count": 26,
  "catalog_products": 24,
  "limitation": "THIS IS: a public library index of Aziel Eliab software plus a counted download of the printed corpus PDF and the library package. THIS IS NOT: a search engine of private files; Zenodo; a new Lock engine; Horton; Revealer. GodLock is a product name in the corpus. Author Aziel Eliab only.",
  "works": [
    {
      "slug": "aziel-corpus-pdf",
      "name": "AZIEL Corpus Library \u2014 software (printed)",
      "one_line": "468-page ReportLab dump of naked source listings (azbot, aziel-runtime, azos, godlock, decisiongate, temporallock, forgereceipts). Counted PDF download.",
      "github": "https://github.com/AzielEliab/aziel-corpus",
      "worker": "aziel-corpus-download-tracker",
      "download": "https://www.azielcorpuslibrary.net/download?asset=AZIEL_Corpus_Library_software.pdf",
      "download_fallback": "https://aziel-corpus-download-tracker.vibelock.workers.dev/download?asset=AZIEL_Corpus_Library_software.pdf",
      "install": "https://www.azielcorpuslibrary.net/install.sh",
      "skill": "https://www.azielcorpuslibrary.net/v1/skill",
      "openapi": "https://www.azielcorpuslibrary.net/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "Printed corpus. Library index + counted PDF download. Not a search engine of private files. Not Zenodo. Not a new Lock engine. Author Aziel Eliab.",
      "kind": "printed-corpus",
      "asset": "AZIEL_Corpus_Library_software.pdf",
      "pages": 468,
      "counted_here": true,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return Aziel Corpus Library skill markdown."
        }
      ]
    },
    {
      "slug": "aziel-corpus",
      "name": "Aziel Corpus Library",
      "one_line": "Public library of Aziel Eliab software. Counted views and downloads. Search + cards. Author Aziel Eliab.",
      "github": "https://github.com/AzielEliab/aziel-corpus",
      "worker": "aziel-corpus-download-tracker",
      "download": "https://www.azielcorpuslibrary.net/download?asset=aziel-corpus-0.1.0.tar.gz",
      "download_fallback": "https://aziel-corpus-download-tracker.vibelock.workers.dev/download?asset=aziel-corpus-0.1.0.tar.gz",
      "install": "https://www.azielcorpuslibrary.net/install.sh",
      "skill": "https://www.azielcorpuslibrary.net/v1/skill",
      "openapi": "https://www.azielcorpuslibrary.net/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "Library index + counted corpus download. Not a search engine of private files. Not Zenodo. Not a new Lock engine. Author Aziel Eliab only.",
      "kind": "library",
      "asset": "aziel-corpus-0.1.0.tar.gz",
      "counted_here": true,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "works",
          "method": "GET",
          "summary": "JSON list of indexed works."
        },
        {
          "op": "search",
          "method": "GET",
          "summary": "Search works by q=."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return Aziel Corpus Library skill markdown."
        },
        {
          "op": "example",
          "method": "GET",
          "summary": "Sample JSON payload."
        }
      ]
    },
    {
      "slug": "vibelock",
      "name": "VibeLock",
      "one_line": "Physical-consistency evaluation of speech audio. Risk assessment, not a liveness proof.",
      "github": "https://github.com/AzielEliab/vibelock",
      "worker": "vibelock-download-tracker",
      "download": "https://vibelock-download-tracker.vibelock.workers.dev/download",
      "install": "https://vibelock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://vibelock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://vibelock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21431610",
      "doi_url": "https://doi.org/10.5281/zenodo.21431610",
      "banner": "Physical-consistency evaluation of speech audio. Risk assessment, not a liveness proof.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "analyze",
          "method": "POST",
          "summary": "Audio forensic risk assessment (JSON metrics)."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return VibeLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/vibelock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/vibelock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/vibelock/skill"
    },
    {
      "slug": "veillock",
      "name": "VeilLock",
      "one_line": "Local camera/screen steps for YOUR device only. Not a call interceptor.",
      "github": "https://github.com/AzielEliab/veillock",
      "worker": "veillock-download-tracker",
      "download": "https://veillock-download-tracker.vibelock.workers.dev/download",
      "install": "https://veillock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://veillock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://veillock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21431659",
      "doi_url": "https://doi.org/10.5281/zenodo.21431659",
      "banner": "VeilLock does not inject into FaceTime, Zoom, Meet, Teams, or Skype. YOUR camera/screen only. Not a call interceptor.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "apps",
          "method": "POST",
          "summary": "Local-app steps. YOUR camera/screen only."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return VeilLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/veillock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/veillock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/veillock/skill"
    },
    {
      "slug": "codelock",
      "name": "CodeLock",
      "one_line": "Canonical or Rosetta HTML view of source. Alters perception, not meaning.",
      "github": "https://github.com/AzielEliab/codelock",
      "worker": "codelock-download-tracker",
      "download": "https://codelock-download-tracker.vibelock.workers.dev/download",
      "install": "https://codelock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://codelock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://codelock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21431561",
      "doi_url": "https://doi.org/10.5281/zenodo.21431561",
      "banner": "This tool alters perception, not meaning.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "render",
          "method": "POST",
          "summary": "Canonical or CodeLock/Rosetta HTML view of source."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return CodeLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/codelock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/codelock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/codelock/skill"
    },
    {
      "slug": "godlock",
      "name": "GodLock",
      "one_line": "Offline ABAD / hardening score. Not a VPN and not an anonymity network.",
      "github": "https://github.com/AzielEliab/godlock",
      "worker": "godlock-download-tracker",
      "download": "https://godlock-download-tracker.vibelock.workers.dev/download",
      "install": "https://godlock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://godlock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://godlock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "GodLock is not a VPN and not an anonymity network.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "score",
          "method": "POST",
          "summary": "Offline ABAD / hardening score for a text."
        },
        {
          "op": "submit",
          "method": "POST",
          "summary": "Submit text; returns a receipt id (no VPN)."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return GodLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/godlock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/godlock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/godlock/skill"
    },
    {
      "slug": "shadowlock",
      "name": "ShadowLock",
      "one_line": "Zero-retention observation of a job list you already have. No OS hook.",
      "github": "https://github.com/AzielEliab/shadowlock",
      "worker": "shadowlock-download-tracker",
      "download": "https://shadowlock-download-tracker.vibelock.workers.dev/download",
      "install": "https://shadowlock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://shadowlock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://shadowlock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21435707",
      "doi_url": "https://doi.org/10.5281/zenodo.21435707",
      "banner": "ShadowLock is a gate on an outcome you already have. No OS hook. No process intercept.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "observe",
          "method": "POST",
          "summary": "Zero-retention observation of a job list you already have."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return ShadowLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/shadowlock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/shadowlock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/shadowlock/skill"
    },
    {
      "slug": "temporallock",
      "name": "TemporalLock",
      "one_line": "Hash-chained receipts anyone can verify. Explicit genesis, append, verify.",
      "github": "https://github.com/AzielEliab/temporallock",
      "worker": "temporallock-download-tracker",
      "download": "https://temporallock-download-tracker.vibelock.workers.dev/download",
      "install": "https://temporallock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://temporallock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://temporallock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21431405",
      "doi_url": "https://doi.org/10.5281/zenodo.21431405",
      "banner": "Hash-chained receipts anyone can verify. Explicit genesis, append, verify.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "genesis",
          "method": "POST",
          "summary": "First receipt of a chain (explicit genesis)."
        },
        {
          "op": "append",
          "method": "POST",
          "summary": "Append a receipt to an existing chain payload."
        },
        {
          "op": "verify",
          "method": "POST",
          "summary": "Recompute hashes. Anyone can verify."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return TemporalLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/temporallock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/temporallock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/temporallock/skill"
    },
    {
      "slug": "forgereceipts",
      "name": "ForgeReceipts",
      "one_line": "Local receipt / checklist helper. Not legal advice. Does not contact courts.",
      "github": "https://github.com/AzielEliab/forgereceipts",
      "worker": "forgereceipts-download-tracker",
      "download": "https://forgereceipts-download-tracker.vibelock.workers.dev/download",
      "install": "https://forgereceipts-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://forgereceipts-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://forgereceipts-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21436074",
      "doi_url": "https://doi.org/10.5281/zenodo.21436074",
      "banner": "ForgeReceipts is not legal advice. It does not contact courts, Odyssey, email, or any cloud filing service.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "receipt",
          "method": "POST",
          "summary": "Local receipt / checklist helper. No court connection."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return ForgeReceipts skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/forgereceipts",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/forgereceipts/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/forgereceipts/skill"
    },
    {
      "slug": "decisiongate",
      "name": "DecisionGATE",
      "one_line": "Five sequential gates on a proposal. Freedom without clarity is chaos.",
      "github": "https://github.com/AzielEliab/decisiongate",
      "worker": "decisiongate-download-tracker",
      "download": "https://decisiongate-download-tracker.vibelock.workers.dev/download",
      "install": "https://decisiongate-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://decisiongate-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://decisiongate-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21435730",
      "doi_url": "https://doi.org/10.5281/zenodo.21435730",
      "banner": "Freedom without clarity is chaos.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "check",
          "method": "POST",
          "summary": "Run the five sequential gates on a proposal."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return DecisionGATE skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/decisiongate",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/decisiongate/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/decisiongate/skill"
    },
    {
      "slug": "zsolver",
      "name": "ZionPattern Solver",
      "one_line": "Nine ontology nodes (Zioncheck seed). Hard 75% cap. Does not solve cases.",
      "github": "https://github.com/AzielEliab/zion-pattern-solver",
      "worker": "zsolver-download-tracker",
      "download": "https://zsolver-download-tracker.vibelock.workers.dev/download",
      "install": "https://zsolver-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://zsolver-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://zsolver-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21436155",
      "doi_url": "https://doi.org/10.5281/zenodo.21436155",
      "banner": "Hard 75% confidence cap / 25% uncertainty floor. Provisional and assistive. Does not solve Zioncheck or any case.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "patterns",
          "method": "GET",
          "summary": "Nine ontology nodes (Zioncheck seed). Not a verdict."
        },
        {
          "op": "score",
          "method": "POST",
          "summary": "Score answers. Hard 75% cap, 25% floor."
        },
        {
          "op": "session",
          "method": "POST",
          "summary": "Stateless session snapshot from answers."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return ZionPattern Solver skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/zsolver",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/zsolver/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/zsolver/skill"
    },
    {
      "slug": "azos",
      "name": "AZ-OS",
      "one_line": "Read-only status / principles. Does not grant remote shell.",
      "github": "https://github.com/AzielEliab/azos",
      "worker": "azos-download-tracker",
      "download": "https://azos-download-tracker.vibelock.workers.dev/download",
      "install": "https://azos-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://azos-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://azos-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21431711",
      "doi_url": "https://doi.org/10.5281/zenodo.21431711",
      "banner": "AZ-OS does not grant remote shell. Invite prints principles; exec requires a local token.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "status",
          "method": "POST",
          "summary": "Read-only status / principles. No remote exec."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return AZ-OS skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/azos",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/azos/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/azos/skill"
    },
    {
      "slug": "glossafilter",
      "name": "Glossa Filter",
      "one_line": "Render an intent across bundled peer ids. Human opinion remains human.",
      "github": "https://github.com/AzielEliab/glossafilter",
      "worker": "glossafilter-download-tracker",
      "download": "https://glossafilter-download-tracker.vibelock.workers.dev/download",
      "install": "https://glossafilter-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://glossafilter-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://glossafilter-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "Human opinion remains human, and tools remain tools.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "render",
          "method": "POST",
          "summary": "Render an intent across bundled peer ids."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return Glossa Filter skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/glossafilter",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/glossafilter/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/glossafilter/skill"
    },
    {
      "slug": "miragegrid",
      "name": "MirageGrid",
      "one_line": "Ephemeral session node assignment. Not a VPN and not an anonymity network.",
      "github": "https://github.com/AzielEliab/miragegrid",
      "worker": "miragegrid-download-tracker",
      "download": "https://miragegrid-download-tracker.vibelock.workers.dev/download",
      "install": "https://miragegrid-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://miragegrid-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://miragegrid-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "MirageGrid is not a VPN and not an anonymity network. It does not guarantee anonymity against global surveillance.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "assign",
          "method": "POST",
          "summary": "Assign a session node id. Mapping is ephemeral."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return MirageGrid skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/miragegrid",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/miragegrid/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/miragegrid/skill"
    },
    {
      "slug": "staticclock",
      "name": "StaticClock",
      "one_line": "Five advisory fields for a geo. Not a scheduler.",
      "github": "https://github.com/AzielEliab/staticclock",
      "worker": "staticclock-download-tracker",
      "download": "https://staticclock-download-tracker.vibelock.workers.dev/download",
      "install": "https://staticclock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://staticclock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://staticclock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "StaticClock is not a scheduler and not a clock you set. Advisory fields only.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "advise",
          "method": "POST",
          "summary": "Five advisory fields for a geo. Not a scheduler."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return StaticClock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/staticclock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/staticclock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/staticclock/skill"
    },
    {
      "slug": "chronolock",
      "name": "ChronoLock",
      "one_line": "Advisory temporal window 08:30\u201310:30 local. Distinct from TemporalLock.",
      "github": "https://github.com/AzielEliab/chronolock",
      "worker": "chronolock-download-tracker",
      "download": "https://chronolock-download-tracker.vibelock.workers.dev/download",
      "install": "https://chronolock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://chronolock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://chronolock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "ChronoLock is advisory only \u2014 not a scheduler, not targeting, not virality. Temporal Neutral Window 08:30\u201310:30 local. Distinct from TemporalLock.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "advisory",
          "method": "POST",
          "summary": "One advisory for a last-known geo. Not a scheduler."
        },
        {
          "op": "anchors",
          "method": "GET",
          "summary": "List Top-30 geographic anchors."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return ChronoLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/chronolock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/chronolock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/chronolock/skill"
    },
    {
      "slug": "postking",
      "name": "Post-King Chess",
      "one_line": "Continuity chess. The goal is not to win. The goal is to remain.",
      "github": "https://github.com/AzielEliab/postking-chess",
      "worker": "postking-download-tracker",
      "download": "https://postking-download-tracker.vibelock.workers.dev/download",
      "install": "https://postking-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://postking-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://postking-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21897338",
      "doi_url": "https://doi.org/10.5281/zenodo.21897338",
      "banner": "The goal is not to win. The goal is to remain. Human is king-bound; AI has a Node, not a king.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "new",
          "method": "POST",
          "summary": "Start a game {difficulty, seed}."
        },
        {
          "op": "move",
          "method": "POST",
          "summary": "Human UCI move + AI 1-ply continuity reply."
        },
        {
          "op": "status",
          "method": "POST",
          "summary": "Continuity status for a FEN/state."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return Post-King Chess skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/postking",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/postking/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/postking/skill"
    },
    {
      "slug": "azclce",
      "name": "AZ-CLCE",
      "one_line": "Jaccard triple / pairwise / CLCE+. Detects inconsistency, not intent.",
      "github": "https://github.com/AzielEliab/az-clce",
      "worker": "azclce-download-tracker",
      "download": "https://azclce-download-tracker.vibelock.workers.dev/download",
      "install": "https://azclce-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://azclce-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://azclce-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "CLCE detects inconsistency, not intent. Type D is a label, not a finding of malice. Threshold 0.7 is advisory.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "score",
          "method": "POST",
          "summary": "Jaccard triple / pairwise / CLCE+."
        },
        {
          "op": "classify",
          "method": "POST",
          "summary": "Mismatch types. Type D is a label only."
        },
        {
          "op": "gate",
          "method": "POST",
          "summary": "Pass iff triple \u2265 min (default 0.7). Advisory."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return AZ-CLCE skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/azclce",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/azclce/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/azclce/skill"
    },
    {
      "slug": "ark",
      "name": "The ARK",
      "one_line": "Mode E heuristics sweep. Not a kernel. Hosted never unlocks or stores vaults.",
      "github": "https://github.com/AzielEliab/ark",
      "worker": "ark-download-tracker",
      "download": "https://ark-download-tracker.vibelock.workers.dev/download",
      "install": "https://ark-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://ark-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://ark-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.21435810",
      "doi_url": "https://doi.org/10.5281/zenodo.21435810",
      "banner": "The ARK is not a kernel. Hosted API never unlocks or encrypts with a passphrase and never stores vaults. Sweep is Mode E heuristics only.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "sweep",
          "method": "POST",
          "summary": "Mode E heuristics only (PE/ELF/Mach-O, powershell -enc, curl|sh). No clamscan. Payload is not stored."
        },
        {
          "op": "levels",
          "method": "GET",
          "summary": "Auto-lock seconds and decoy counts. Behavior, not cryptography."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return The ARK skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/ark",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/ark/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/ark/skill"
    },
    {
      "slug": "azai",
      "name": "AZAI",
      "one_line": "Local OpenAI-compatible runtime. Not a new foundation model. Jeeves is not sovereign.",
      "github": "https://github.com/AzielEliab/azai",
      "worker": "azai-download-tracker",
      "download": "https://azai-download-tracker.vibelock.workers.dev/download",
      "install": "https://azai-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://azai-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://azai-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "AZAI is a local OpenAI-compatible runtime, not a new foundation model. Hosted /v1 is a protocol mirror + Lamb check, NOT a proxy that spends the author's paid keys. Jeeves is not sovereign. Live blend is local azai serve.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Protocol mirror. Not a provider proxy."
        },
        {
          "op": "lamb-check",
          "method": "POST",
          "summary": "Run Lamb Lens (peace/clarity/service) on {text}. No provider call."
        },
        {
          "op": "lamb_check",
          "method": "POST",
          "summary": "Alias of lamb-check for MCP azai_lamb_check."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return AZAI skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/azai",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/azai/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/azai/skill"
    },
    {
      "slug": "spectrallock",
      "name": "SpectralLock",
      "one_line": "Overlay preview modes. 256px hosted preview, not a spectrometer.",
      "github": "https://github.com/AzielEliab/spectrallock",
      "worker": "spectrallock-download-tracker",
      "download": "https://spectrallock-download-tracker.vibelock.workers.dev/download",
      "install": "https://spectrallock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://spectrallock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://spectrallock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "Hosted overlay is a 256px preview, not a spectrometer, not forensic.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV."
        },
        {
          "op": "modes",
          "method": "GET",
          "summary": "List live overlay modes (zero, tazel, vyrn, uv, rosetta, zen, chaos, balance)."
        },
        {
          "op": "overlay",
          "method": "POST",
          "summary": "Simplified overlay preview. PNG b64 in, longest side capped at 256 px. Not the full Python pipeline."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return SpectralLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/spectrallock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/spectrallock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/spectrallock/skill"
    },
    {
      "slug": "azbot",
      "name": "AZBot",
      "one_line": "Skill, not a foundation model. Hosted /v1/skill returns markdown.",
      "github": "https://github.com/AzielEliab/azbot",
      "worker": "azbot-download-tracker",
      "download": "https://azbot-download-tracker.vibelock.workers.dev/download",
      "install": "https://azbot-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://azbot-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://azbot-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": null,
      "doi_url": null,
      "banner": "AZBot is a skill, not a foundation model. Hosted /v1/skill returns markdown. Call aziel-runtime for the engines. Jeeves is not sovereign.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Skill, not a model."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return AZBot skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/azbot",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/azbot/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/azbot/skill"
    },
    {
      "slug": "employeelock",
      "name": "EmployeeLock",
      "one_line": "Hash-chained accountability workbook. Not a court, not UL, not a truth score.",
      "github": "https://github.com/AzielEliab/employeelock",
      "worker": "employeelock-download-tracker",
      "download": "https://employeelock-download-tracker.vibelock.workers.dev/download",
      "install": "https://employeelock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://employeelock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://employeelock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.22257493",
      "doi_url": "https://doi.org/10.5281/zenodo.22257493",
      "banner": "EmployeeLock is a hash-chained accountability workbook. Not a court, not UL, not a truth score. Hosted never stores xlsx. Demo rows are format proof, not case facts.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV. Hosted never stores xlsx."
        },
        {
          "op": "append-preview",
          "method": "POST",
          "summary": "Hash a proposed LOG row without writing a file. Hosted never stores xlsx."
        },
        {
          "op": "verify-canonical",
          "method": "POST",
          "summary": "Recompute SHA-256 of posted canonical JSON. Not a truth score."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return EmployeeLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/employeelock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/employeelock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/employeelock/skill"
    },
    {
      "slug": "foldlock",
      "name": "FoldLock",
      "one_line": "Algorithmic tether-word suppression on UTF-8 text. Not zip.",
      "github": "https://github.com/AzielEliab/foldlock",
      "worker": "foldlock-download-tracker",
      "download": "https://foldlock-download-tracker.vibelock.workers.dev/download",
      "install": "https://foldlock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://foldlock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://foldlock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.22257762",
      "doi_url": "https://doi.org/10.5281/zenodo.22257762",
      "banner": "FoldLock is algorithmic tether-word suppression on UTF-8 text. Not zip. Hosted preview is not a general compressor. Ratios are receipts, not trophies. Short strings can grow.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV. Not zip."
        },
        {
          "op": "fold-preview",
          "method": "POST",
          "summary": "Small UTF-8 text in, receipt + FLD3 base64 out. Cap ~8KB. Not zip."
        },
        {
          "op": "unfold-preview",
          "method": "POST",
          "summary": "FLD3 base64 in, verified restore or error. Not zip."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return FoldLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/foldlock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/foldlock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/foldlock/skill"
    },
    {
      "slug": "whistlelock",
      "name": "WhistleLock",
      "one_line": "Local drop ledger + dead-man copy. Not a mailer.",
      "github": "https://github.com/AzielEliab/whistlelock",
      "worker": "whistlelock-download-tracker",
      "download": "https://whistlelock-download-tracker.vibelock.workers.dev/download",
      "install": "https://whistlelock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://whistlelock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://whistlelock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.22257762",
      "doi_url": "https://doi.org/10.5281/zenodo.22257762",
      "banner": "WhistleLock is a local drop ledger + dead-man copy. Not a mailer. Hosted never holds whistle files. The operator moves released packets.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV. Hosted never holds whistle files."
        },
        {
          "op": "hash-preview",
          "method": "POST",
          "summary": "SHA-256 of posted bytes. Not stored. Hosted never holds whistle files."
        },
        {
          "op": "canon-preview",
          "method": "POST",
          "summary": "Hash a proposed ledger row. Not stored. Not a mailer."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return WhistleLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/whistlelock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/whistlelock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/whistlelock/skill"
    },
    {
      "slug": "trajectorylock",
      "name": "TrajectoryLock",
      "one_line": "Auditable geometric test. Research prototype, not a certified forensic instrument.",
      "github": "https://github.com/AzielEliab/trajectorylock",
      "worker": "trajectorylock-download-tracker",
      "download": "https://trajectorylock-download-tracker.vibelock.workers.dev/download",
      "install": "https://trajectorylock-download-tracker.vibelock.workers.dev/install.sh",
      "skill": "https://trajectorylock-download-tracker.vibelock.workers.dev/v1/skill",
      "openapi": "https://trajectorylock-download-tracker.vibelock.workers.dev/openapi.json",
      "doi": "10.5281/zenodo.22258015",
      "doi_url": "https://doi.org/10.5281/zenodo.22258015",
      "banner": "TrajectoryLock is a research prototype / auditable geometric test. Not a certified forensic instrument. Hosted never stores media. Match probability is P(match | declared model), not P(official account is true). Synthetic example results must never be represented as real-case findings.",
      "kind": "product",
      "counted_here": false,
      "ops": [
        {
          "op": "health",
          "method": "GET",
          "summary": "Liveness. Does not increment download KV. Hosted never stores media. Not a certified instrument."
        },
        {
          "op": "example",
          "method": "GET",
          "summary": "Synthetic small JSON case. Not a real case. Does not increment download KV."
        },
        {
          "op": "analyze",
          "method": "POST",
          "summary": "Small JSON case in, geometric result out. Cap size. NEVER store media. Not a certified forensic instrument."
        },
        {
          "op": "skill",
          "method": "GET",
          "summary": "Return TrajectoryLock skill markdown. Does not increment download KV."
        }
      ],
      "catalog_card": "https://aziel-runtime.vibelock.workers.dev/p/trajectorylock",
      "catalog_health": "https://aziel-runtime.vibelock.workers.dev/p/trajectorylock/health",
      "catalog_skill": "https://aziel-runtime.vibelock.workers.dev/p/trajectorylock/skill"
    }
  ]
};
